# pls-module
Python package for IPLS using identified peak areas in the spectra
